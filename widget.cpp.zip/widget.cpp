#include "widget.h"
#include "ui_widget.h"
#include <QPaintEvent>
#include <QPainter>

Widget::Widget(QWidget *parent) :
    QWidget(parent),
    ui(new Ui::Widget)
{
    ui->setupUi(this);
    //connect(ui->, SIGNAL, this, SLOT())
}

Widget::~Widget()
{
    delete ui;
}

void Widget::paintEvent(QPaintEvent *e)
{
    QPainter painter(this);

    int width = this->width();
    int height = 2 * this->height();

    int x = 0;
    int y = 0;

    int onex = width/14;
    int oney = height/14;

    painter.setPen(Qt::black);
    painter.setBrush(Qt::red);

    QString Qtcolour[7] = {"red"}; //Qt::darkYellow, Qt::yellow, Qt::green, Qt::blue, Qt::darkBlue, Qt::darkBlue};

    for(int i=0; i<7; i++) {
        painter.setPen(Qt::black);
        painter.setBrush(QBrush(Qt::Qtcolour[i]));
        painter.drawEllipse(x,y, width,height);
        x = x + onex;
        y = y + oney;
        width = width - 2 * onex;
        height = height - 2 * oney;
    }
}
